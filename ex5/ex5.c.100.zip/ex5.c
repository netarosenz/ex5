#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Song {
    char* title;
    char* artist;
    int year;
    char* lyrics;
    int streams;
} Song;

typedef struct Playlist {
    char* name;
    Song** songs;
    int songsNum;
} Playlist;

void addPlaylist(Playlist ***playlists_ptr, int *playlistsNum);
char *readString();
void addSong(Playlist *playlist);
void playSong(Song *song);
void freeSong(Song *song);
Song *createSong(char *title, char *artist, int year, char *lyrics);
void handlePlaylistMenu(Playlist *selectedPlaylist);
int watchPlaylist(Playlist **playlists, int playlistNum);

int stringLength(char *string) {
    int length = 0;
    while(string[length] != '\0') {
        length++;
    }
    return length;
}

void freeSong(Song *song) {
    if(song != NULL) {
        free(song->title);
        free(song->artist);
        free(song->lyrics);
        free(song);
    }
}

void playPlaylist(Playlist *playlist) {
    if(playlist->songsNum == 0) {
        return;
    }
    for(int i = 0; i < playlist->songsNum; i++) {
        playSong(playlist->songs[i]);
    }
}

void sortByYear(Playlist *playlist) {
    if(playlist->songsNum <= 1) {
        return;
    }
    for(int i = 0; i < playlist->songsNum - 1; i++) {
        for(int j = 0; j < playlist->songsNum - i - 1; j++) {
            if(playlist->songs[j]->year > playlist->songs[j + 1]->year) {
                Song *temp = playlist->songs[j];
                playlist->songs[j] = playlist->songs[j + 1];
                playlist->songs[j + 1] = temp;
            }
        }
    }
}

void sortByStreamsAscending(Playlist *playlist) {
    if(playlist->songsNum <= 1) {
        return;
    }
    for(int i = 0; i < playlist->songsNum - 1; i++) {
        for(int j = 0; j < playlist->songsNum - i - 1; j++) {
            if(playlist->songs[j]->streams > playlist->songs[j + 1]->streams) {
                Song *temp = playlist->songs[j];
                playlist->songs[j] = playlist->songs[j + 1];
                playlist->songs[j + 1] = temp;
            }
        }
    }
}

void sortByStreamsDescending(Playlist *playlist) {
    if(playlist->songsNum <= 1) {
        return;
    }
    for(int i = 0; i < playlist->songsNum - 1; i++) {
        for(int j = 0; j < playlist->songsNum - i - 1; j++) {
            if(playlist->songs[j]->streams < playlist->songs[j + 1]->streams) {
                Song *temp = playlist->songs[j];
                playlist->songs[j] = playlist->songs[j + 1];
                playlist->songs[j + 1] = temp;
            }
        }
    }
}

void sortByAlphabetically(Playlist *playlist) {
    if(playlist->songsNum <= 1) {
        return;
    }
    for(int i = 0; i < playlist->songsNum - 1; i++) {
        for(int j = 0; j < playlist->songsNum - i - 1; j++) {
            if(strcmp(playlist->songs[j]->title, playlist->songs[j + 1]->title) > 0) {
                Song *temp = playlist->songs[j];
                playlist->songs[j] = playlist->songs[j + 1];
                playlist->songs[j + 1] = temp;
            }
        }
    }
}

void sortPlaylist(Playlist *playlist) {
    int choice;
    printf("choose:\n");
    printf("1. sort by year\n");
    printf("2. sort by streams - ascending order\n");
    printf("3. sort by streams - descending order\n");
    printf("4. sort alphabetically\n");
    scanf("%d", &choice);
    if(choice < 1 || choice > 4) {
        choice = 4;
    }
    switch (choice) {
        case 1: {
            sortByYear(playlist);
            break;
        }
        case 2: {
            sortByStreamsAscending(playlist);
            break;
        }
        case 3: {
            sortByStreamsDescending(playlist);
            break;
        }
        case 4: {
            sortByAlphabetically(playlist);
            break;
        }
    }
    printf("sorted\n");
}

void deleteSong(Playlist *playlist) {
    int choice;
    if (playlist->songsNum > 0) {
        for (int i = 0; i < playlist->songsNum; i++) {
            printf("%d. Title: %s\n", i + 1, playlist->songs[i]->title);
            printf("Artist: %s\n", playlist->songs[i]->artist);
            printf("Released: %d\n", playlist->songs[i]->year);
            printf("Streams: %d\n", playlist->songs[i]->streams);
            printf("\n");
        }
    }
    printf("choose a song to delete, or 0 to quit:\n");
    scanf("%d", &choice);
    if (choice == 0) {
        return;
    }
    if(choice <= playlist->songsNum) {
        freeSong(playlist->songs[choice-1]);
        for(int i = choice - 1; i < playlist->songsNum - 1; i++) {
            playlist->songs[i] = playlist->songs[i + 1];
        }
        playlist->songsNum--;
        printf("Song deleted successfully.\n");
    }
}

Song *createSong(char *title, char *artist, int year, char *lyrics) {
    Song *newSong = (Song*)malloc(sizeof(Song));
    if (newSong == NULL) {
        return NULL;
    }
    newSong->title = (char*)malloc(stringLength(title) + 1);
    if (newSong->title == NULL) {
        free(newSong);
        return NULL;
    }
    newSong->artist = (char*)malloc(stringLength(artist) + 1);
    if (newSong->artist == NULL) {
        free(newSong->title);
        free(newSong);
        return NULL;
    }
    newSong->lyrics = (char*)malloc(stringLength(lyrics) + 1);
    if (newSong->lyrics == NULL) {
        free(newSong->title);
        free(newSong->artist);
        free(newSong);
        return NULL;
    }
    int i;
    for(i = 0; title[i] != '\0'; i++) {
        newSong->title[i] = title[i];
    }
    newSong->title[i] = '\0';
    for(i = 0; artist[i] != '\0'; i++) {
        newSong->artist[i] = artist[i];
    }
    newSong->artist[i] = '\0';
    for(i = 0; lyrics[i] != '\0'; i++) {
        newSong->lyrics[i] = lyrics[i];
    }
    newSong->lyrics[i] = '\0';
    newSong->year = year;
    newSong->streams = 0;
    return newSong;
}

void addSong(Playlist *playlist) {
    char *title;
    char *artist;
    char *lyrics;
    int year;
    Song *newSong;
    printf("Enter song's details\n");
    printf("Title:\n");
    title = readString();
    printf("Artist:\n");
    artist = readString();
    printf("Year of release:\n");
    while (scanf("%d", &year) != 1) {
        while (getchar() != '\n');
    }
    getchar();
    printf("Lyrics:\n");
    lyrics = readString();
    newSong = createSong(title, artist, year, lyrics);
    free(title);
    free(artist);
    free(lyrics);
    Song **temp = (Song**)realloc(playlist->songs, sizeof(Song*) * (playlist->songsNum +1));
    if (temp == NULL) {
        freeSong(newSong);
        return;
    }
    playlist->songs = temp;
    playlist->songs[playlist->songsNum] = newSong;
    playlist->songsNum++;
}

void playSong(Song *song) {
    printf("Now playing %s:\n", song->title);
    printf("$ %s $\n", song->lyrics);
    song->streams++;
    printf("\n");
}

void showPlaylist(Playlist *playlist) {
    int choice;
    if (playlist->songsNum > 0) {
        for (int i = 0; i < playlist->songsNum; i++) {
            printf("%d. Title: %s\n", i + 1, playlist->songs[i]->title);
            printf("Artist: %s\n", playlist->songs[i]->artist);
            printf("Released: %d\n", playlist->songs[i]->year);
            printf("Streams: %d\n", playlist->songs[i]->streams);
        }
        do {
            printf("choose a song to play, or 0 to quit:\n");
            if (scanf("%d", &choice) != 1) {
                while (getchar() != '\n');
                continue;
            }
            getchar();
            if (choice != 0 && choice <= playlist->songsNum) {
                playSong(playlist->songs[choice - 1]);
            }
        }
        while (choice != 0);
    }
}

//this function used for get string from the user, the function retuen pointer to the memory they keep the data
char *readString() {
    //started size
    int length = 0;
    char c;
    //create the first cher
    char *str = (char *) malloc(sizeof(char));
    if (!str) {
        exit(1);
    }
    scanf(" %c", &c);
    //loop that collect chars untill the user press enter
    while (c != '\n' && c != '\r') {
        char *temp = (char *) realloc(str, (length + 2) * sizeof(char));
        if (!temp) {
            free(str);
            exit(1);
        }
        str = temp;
        str[length] = c;
        length++;
        scanf("%c", &c);
    }
    //add the \0 for the compiler to know it arrived to the end of the string
    str[length] = '\0';
    return str;
}

void freeAllMemory(Playlist **playlists, int playlistsNum) {
    if (playlists == NULL) return;
    for (int i = 0; i < playlistsNum; i++) {
        if (playlists[i] != NULL) {
            if (playlists[i]->songs != NULL) {
                for (int j = 0; j < playlists[i]->songsNum; j++) {
                    freeSong(playlists[i]->songs[j]);
                }
                free(playlists[i]->songs);
            }
            if (playlists[i]->name != NULL) {
                free(playlists[i]->name);
            }
            free(playlists[i]);
        }
    }
    free(playlists);
}

void removePlaylist(Playlist **playlists, int *playlistNum) {
    int choice;
    Playlist *toDelete;

    printf("Choose a playlist:\n");
    for(int i = 0; i < *playlistNum; i++) {
        printf("\t%d. %s\n", i + 1, playlists[i]->name);
    }
    printf("\t%d. Back to main menu\n", *playlistNum + 1);
    scanf("%d", &choice);
    if(choice == *playlistNum +1) {
        return;
    }
    if(choice > 0 && choice <= *playlistNum) {
        toDelete = playlists[choice - 1];
        for(int i = 0; i < toDelete->songsNum; i++) {
            freeSong(toDelete->songs[i]);
        }
        free(toDelete->songs);
        free(toDelete->name);
        free(toDelete);
        for(int i = choice - 1; i < *playlistNum - 1; i++) {
            playlists[i] = playlists[i + 1];
        }
        (*playlistNum)--;
        printf("Playlist deleted.\n");
    }
}

void addPlaylist(Playlist ***playlists_ptr, int *playlistsNum) {
    Playlist **playlists = *playlists_ptr;
    printf("Enter playlist's name:\n");
    getchar();
    char* playlistName = readString();
    if (playlistName == NULL) {
        return;
    }
    Playlist* newPlaylist = malloc(sizeof(Playlist));
    if (newPlaylist == NULL) {
        free(playlistName);
        return;
    }
    newPlaylist->name = playlistName;
    newPlaylist->songs = NULL;
    newPlaylist->songsNum = 0;

    if (playlists == NULL) {
        playlists = malloc(sizeof(Playlist*));
        if (playlists == NULL) {
            free(playlistName);
            free(newPlaylist);
            return;
        }
    } else {
        Playlist **temp = realloc(playlists, sizeof(Playlist*) * (*playlistsNum + 1));
        if (temp == NULL) {
            free(playlistName);
            free(newPlaylist);
            return;
        }
        playlists = temp;
    }
    playlists[*playlistsNum] = newPlaylist;
    *playlists_ptr = playlists;
    (*playlistsNum)++;
}

int printMainMenu (){
    int choice;
    printf("Please Choose:\n\t1. Watch playlists\n\t2. Add playlist\n\t3. Remove playlist\n\t4. exit\n");
    scanf("%d", &choice);
    return choice;
}

void handlePlaylistMenu(Playlist *selectedPlaylist) {
    int playlistChoice;
    printf("playlist %s:\n", selectedPlaylist->name);
    do {
        printf("\t1. Show Playlist\n\t2. Add Song\n\t3. Delete Song\n\t4. Sort\n\t5. Play\n\t6. exit\n");
        scanf("%d", &playlistChoice);
        getchar();
        switch (playlistChoice) {
            case 1:
                showPlaylist(selectedPlaylist);
            break;
            case 2:
                addSong(selectedPlaylist);
            break;
            case 3:
                deleteSong(selectedPlaylist);
            break;
            case 4:
                sortPlaylist(selectedPlaylist);
            break;
            case 5:
                playPlaylist(selectedPlaylist);
            break;
            case 6:
                return;
        }
    } while (playlistChoice != 6);
}

int watchPlaylist(Playlist **playlists, int playlistNum) {
    int choice;
    do {
        if (playlists == NULL || playlistNum == 0) {
            printf("Choose a playlist:\n1. Back to main menu\n");
            scanf("%d", &choice);
            return 1;
        }
        printf("Choose a playlist:\n");
        for (int i = 0; i < playlistNum; i++) {
            printf("%d. %s\n", i + 1, playlists[i]->name);
        }
        printf("%d. Back to main menu\n", playlistNum + 1);
        scanf("%d", &choice);
        if (choice == playlistNum + 1) {
            return 1;
        }
        if (choice > 0 && choice <= playlistNum) {
            handlePlaylistMenu(playlists[choice - 1]);
        }
    } while (choice != playlistNum + 1);
    return 1;
}

int main() {
    Playlist **playlists = NULL;
    int playlistsNum = 0;
    int choice = 0;
    do {
        choice = printMainMenu();
        switch (choice) {
            case 1: {
                watchPlaylist(playlists, playlistsNum);
                    break;
                }
            case 2: {
                addPlaylist(&playlists, &playlistsNum);
                break;
            }
            case 3: {
                removePlaylist(playlists, &playlistsNum);
                break;
            }
            case 4: {
                    freeAllMemory(playlists, playlistsNum);
                    printf("Goodbye!\n");
                break;
            }
            default: {
                printf("Invalid Choice.\n");
                break;
            }
        }
    } while (choice != 4);
    return 0;
}
