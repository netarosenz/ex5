instructions are here: https://docs.google.com/document/d/1ACk2ODlm2YygxeJ5AiAxe04hLwDSJyVp8hIJ1PuZfz0/edit?tab=t.0
